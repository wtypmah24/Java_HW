package lesson;

public class Main {
    public static void main(String[] args) {

        char ch = 'A';
        //System.out.println(ch);

        int intCh = ch;
        //System.out.println(intCh);
        //System.out.println("_____________________");

        //_____________________________

        int i = 65;

        //System.out.println(i);

        char num = (char) i;

        //System.out.println(num);

        int firstInt = 100500;
        long firstLong = firstInt;

        //System.out.println(firstInt);
        //System.out.println(firstLong);

        //byte firstByte = (byte) firstInt;

        //System.out.println(firstByte);

        int x = 15;
        long y = 63L;

        int result = (int) (x + y);


        String str = "i love java";
        int index = str.indexOf('j');
        System.out.println(index);

    }
}
